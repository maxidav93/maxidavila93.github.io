document.addEventListener("DOMContentLoaded", function() {
    const pLaboral = document.getElementById('pLaboral', 'pAcademico', 'pDeportivo');
    pLaboral.addEventListener('click', function() {
        window.open('https://www.facebook.com/profile.php?id=100062091743496', 'https://drive.google.com/drive/folders/1k2PHk7bMJwa_qc5v81Ku19Fp2ENDFqNK?usp=sharing', 'https://diarioelpueblo.com.uy/maximiliano-davila-hijo-y-nieto-de-saltenos-medalla-de-oro-en-sambo/'); 
    });
  });